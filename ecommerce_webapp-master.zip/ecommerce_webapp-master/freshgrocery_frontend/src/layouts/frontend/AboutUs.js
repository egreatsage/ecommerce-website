import React from 'react'


const AboutUs = () => {
  return (
    <div>
      I am about us
    </div>
  )
}

export default AboutUs