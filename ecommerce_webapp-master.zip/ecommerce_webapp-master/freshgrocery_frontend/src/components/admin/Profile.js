import React from 'react'

function Profile() {
  return (
    <div>I am Profile</div>
  )
}

export default Profile