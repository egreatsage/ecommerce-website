import React from 'react'

function Dashboard() {
  return (
    <div>I am dashboard</div>
  )
}

export default Dashboard