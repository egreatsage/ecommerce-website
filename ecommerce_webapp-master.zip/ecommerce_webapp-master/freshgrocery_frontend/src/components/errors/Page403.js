import React from 'react'

const Page403 = () => {
  return (
    <div className='container'>
        <div className="row justify-content-center">
            <div className="card card-body">
                <h1>Page 403 | Forbidden</h1>
                <h3>Access denied! as you are not an Admin</h3>
            </div>
        </div>
    </div>
  )
}

export default Page403