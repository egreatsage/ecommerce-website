export const initialUsers = [

    {
        id: 1,
        username: "user",
        email: "email@gmail.com",
        password: "password"
    },

    {
        id: 2,
        username: "user2",
        email: "user@gmail.com",
        password: "password",
    }

]